# Evidencias Tarea 1

## Clase en JavaScript

```javascript
// tarea1.js

// Clase que representa un objeto de ejemplo: Libro
class Libro {
  #autor;         // privado
  titulo;         // público
  paginas;        // público
  genero;         // público

  constructor(titulo, paginas, autor, genero) {
    this.titulo = titulo;
    this.paginas = paginas;
    this.#autor = autor;
    this.genero = genero;
  }

  // Método tradicional: descripción del libro
  descripcion() {
    console.log(`"${this.titulo}" es un libro de ${this.genero} con ${this.paginas} páginas.`);
  }

  // Arrow function: mostrar título en mayúsculas
  mostrarTitulo = () => {
    console.log(`TITULO: ${this.titulo.toUpperCase()}`);
  }
}

// Crear instancias
const libro1 = new Libro("Cien Años de Soledad", 417, "Gabriel García Márquez", "Realismo mágico");
const libro2 = new Libro("El Principito", 96, "Antoine de Saint-Exupéry", "Fábula");
```

## Ejecución y salidas

**Comando para ejecutar:**
```
node tarea1.js
```

**Salida en consola:**

![Captura de salida](evidencia/captura_salida.png)

**Captura del código en VS Code:**

![Captura de código](evidencia/captura_codigo.png)
