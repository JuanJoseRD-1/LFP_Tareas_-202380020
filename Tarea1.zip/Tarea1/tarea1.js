// tarea1.js

// Clase que representa un objeto de ejemplo: Libro
class Libro {
  #autor;         // privado
  titulo;         // público
  paginas;        // público
  genero;         // público

  constructor(titulo, paginas, autor, genero) {
    this.titulo = titulo;
    this.paginas = paginas;
    this.#autor = autor;
    this.genero = genero;
  }

  // Método tradicional: descripción del libro
  descripcion() {
    console.log(`"${this.titulo}" es un libro de ${this.genero} con ${this.paginas} páginas.`);
  }

  // Arrow function: mostrar título en mayúsculas
  mostrarTitulo = () => {
    console.log(`TITULO: ${this.titulo.toUpperCase()}`);
  }
}

// Crear dos instancias
const libro1 = new Libro("Cien Años de Soledad", 417, "Gabriel García Márquez", "Realismo mágico");
const libro2 = new Libro("El Principito", 96, "Antoine de Saint-Exupéry", "Fábula");

// Probar métodos
console.log("=== Prueba libro1 ===");
libro1.descripcion();
libro1.mostrarTitulo();

console.log("=== Prueba libro2 ===");
libro2.descripcion();
libro2.mostrarTitulo();
