// app.js
// Tarea 2 - Manejo de archivos (Node.js)
// Requisitos: mostrar menú, leer archivo inventario.inv con fs y readline, manejo de excepciones.

const fs = require('fs');
const readline = require('readline');

const INVENTARIO_FILE = 'inventario.inv';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function mostrarMenu() {
  console.log('\n=== MENÚ ===');
  console.log('1. Leer archivo .inv e imprimir su contenido.');
  console.log('2. Salir.');
  rl.question('Seleccione una opción: ', (op) => {
    handleOption(op.trim());
  });
}

function handleOption(op) {
  if (op === '1') {
    leerInventario(() => {
      // Después de leer, mostrar el menú de nuevo
      mostrarMenu();
    });
  } else if (op === '2') {
    console.log('Saliendo. ¡Hasta luego!');
    rl.close();
  } else {
    console.log('Opción no válida. Intente de nuevo.');
    mostrarMenu();
  }
}

function leerInventario(callback) {
  try {
    if (!fs.existsSync(INVENTARIO_FILE)) {
      console.log(`Error: El archivo "${INVENTARIO_FILE}" no existe.`);
      callback();
      return;
    }

    const fileStream = fs.createReadStream(INVENTARIO_FILE, { encoding: 'utf8' });
    const rlFile = require('readline').createInterface({
      input: fileStream,
      crlfDelay: Infinity
    });

    console.log(`\nContenido de ${INVENTARIO_FILE}:`);
    rlFile.on('line', (line) => {
      if (line.trim().length > 0) {
        console.log(line);
      }
    });

    rlFile.on('close', () => {
      console.log('\n--- Fin del archivo ---');
      callback();
    });

  } catch (err) {
    console.log('Ocurrió un error al leer el archivo:', err.message);
    callback();
  }
}

// Inicio del programa
console.log('Programa: Manejo de archivos - inventario');
mostrarMenu();

// Manejo de Ctrl+C para cerrar adecuadamente
process.on('SIGINT', () => {
  console.log('\nInterrumpido. Cerrando.');
  rl.close();
  process.exit();
});
