# Tarea 2 - Manejo de archivos (Node.js)

Contenido del paquete:
- `app.js` : Código fuente en Node.js (usa `fs` y `readline`).
- `package.json` : Archivo de proyecto.
- `inventario.inv` : Archivo de datos con ejemplo.
- `screenshots.pdf` : PDF con capturas de pantalla simuladas del funcionamiento.
- `README.md` : Este archivo.

## Instrucciones para ejecutar (en su máquina con Node.js instalado)

1. Abrir una terminal y posicionarse en la carpeta `Tarea2`:
   ```
   cd LFP_Tareas_#Carnet/Tarea2
   ```

2. Instalar dependencias (no hay dependencias externas, paso opcional):
   ```
   npm install
   ```

3. Ejecutar la aplicación:
   ```
   node app.js
   ```
   o
   ```
   npm start
   ```

## Comportamiento esperado
- Al iniciar mostrará un menú con dos opciones: leer el archivo `.inv` e imprimir su contenido; o salir.
- Si el archivo no existe, mostrará un mensaje de error y regresará al menú (no terminará el programa).
- Al seleccionar la opción 1 mostrará cada línea del archivo por consola y luego volverá al menú.

## Nota
Las capturas en `screenshots.pdf` son simulaciones del comportamiento para facilitar la entrega y la toma de capturas.
